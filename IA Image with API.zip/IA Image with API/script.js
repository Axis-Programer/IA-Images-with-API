async function generateImage() {
    const prompt = document.getElementById('prompt').value;
    const response = await fetch('/generate-image', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ prompt: prompt })
    });

    const data = await response.json();

    if (data.error) {
        alert('Error generando la imagen');
    } else {
        const imageUrl = data.data[0].url;
        document.getElementById('image-container').innerHTML = `<img src="${imageUrl}" alt="Imagen generada">`;
    }
}
